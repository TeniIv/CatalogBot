config = {
	'name': 'Catalog_bookBot',
	'token': '6150285734:AAHGwFdNDqddXUuieeHQcbkg58T2_6uvkZQ',
	'tokenqiwi': '*****************',
	'phoneqiwi': '+7(***)***-**-**'
}